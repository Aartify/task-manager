/* ═══════════════════════════════════════════════════
   TaskAI — app.js
   Claude-powered task manager: urgency scoring,
   inline AI tips, daily briefing, smart chat
═══════════════════════════════════════════════════ */

// ── State ─────────────────────────────────────────
let tasks = JSON.parse(localStorage.getItem('taskAI_tasks') || '[]');
let currentFilter = 'all';
let currentSort   = 'urgency';
let currentView   = 'dashboard';
let chatHistory   = [];   // [{role,content}]

// ── Helpers ───────────────────────────────────────
const $ = id => document.getElementById(id);
const esc = s => String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2);
const save = () => localStorage.setItem('taskAI_tasks', JSON.stringify(tasks));

// ── Urgency Score ──────────────────────────────────
// Returns a number 0–100. Higher = more urgent.
// Factors: priority weight + deadline proximity
function urgencyScore(task) {
  if (task.done) return -1;
  const priorityBase = { high: 60, medium: 35, low: 15 }[task.priority] || 15;
  if (!task.due) return priorityBase;

  const today = new Date(); today.setHours(0,0,0,0);
  const due   = new Date(task.due + 'T00:00:00');
  const diff  = Math.round((due - today) / 86400000); // days until due

  let deadlineScore = 0;
  if (diff < 0)       deadlineScore = 40;   // overdue
  else if (diff === 0) deadlineScore = 35;   // due today
  else if (diff === 1) deadlineScore = 28;   // due tomorrow
  else if (diff <= 3)  deadlineScore = 20;
  else if (diff <= 7)  deadlineScore = 10;
  else                 deadlineScore = 2;

  return Math.min(100, priorityBase + deadlineScore);
}

function dueInfo(dateStr) {
  if (!dateStr) return null;
  const today = new Date(); today.setHours(0,0,0,0);
  const due   = new Date(dateStr + 'T00:00:00');
  const diff  = Math.round((due - today) / 86400000);
  if (diff < 0)  return { label: `${Math.abs(diff)}d overdue`, cls: 'overdue', badge: '🔴 Overdue' };
  if (diff === 0) return { label: 'Due today',    cls: 'today',    badge: '🟡 Today' };
  if (diff === 1) return { label: 'Due tomorrow', cls: 'tomorrow', badge: '🟠 Tomorrow' };
  const d = due.toLocaleDateString('en-US',{month:'short',day:'numeric'});
  return { label: `Due ${d}`, cls: 'soon', badge: `📅 ${d}` };
}

function urgencyClass(score) {
  if (score >= 80) return 'u-critical';
  if (score >= 55) return 'u-high';
  if (score >= 30) return 'u-medium';
  return 'u-low';
}

function isUrgent(task) { return urgencyScore(task) >= 55; }

// ── Toast ──────────────────────────────────────────
function toast(msg, type = '', duration = 3500) {
  const container = $('toast-container');
  const el = document.createElement('div');
  el.className = `toast${type ? ' toast-' + type : ''}`;
  el.innerHTML = msg;
  container.appendChild(el);
  requestAnimationFrame(() => { requestAnimationFrame(() => el.classList.add('show')); });
  setTimeout(() => {
    el.classList.remove('show');
    setTimeout(() => el.remove(), 400);
  }, duration);
}

// ── Claude API ─────────────────────────────────────
async function callClaude(messages, system = '', maxTokens = 800) {
  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'anthropic-version': '2023-06-01',
      'anthropic-dangerous-direct-browser-access': 'true',
      // Add your key here: 'x-api-key': 'sk-ant-...'
    },
    body: JSON.stringify({
      model: 'claude-sonnet-4-20250514',
      max_tokens: maxTokens,
      system,
      messages,
    })
  });
  if (!response.ok) throw new Error(`Claude API error ${response.status}`);
  const data = await response.json();
  return data.content?.find(b => b.type === 'text')?.text || '';
}

// Build a rich task context string for every API call
function taskContext() {
  if (tasks.length === 0) return 'The user has no tasks yet.';
  const active    = tasks.filter(t => !t.done);
  const completed = tasks.filter(t => t.done);
  const urgent    = active.filter(isUrgent);
  const today     = new Date().toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric'});

  const fmt = t => {
    const score = urgencyScore(t);
    const due   = t.due ? ` | due: ${t.due}` : '';
    return `- [${t.priority.toUpperCase()}] urgency:${score} "${t.title}"${t.desc ? ' — ' + t.desc : ''}${due}${t.done ? ' [DONE]' : ''}`;
  };

  return [
    `Today is ${today}.`,
    `Tasks — ${active.length} active, ${completed.length} completed, ${urgent.length} urgent.`,
    '',
    'ACTIVE TASKS (sorted by urgency):',
    ...active.sort((a,b) => urgencyScore(b)-urgencyScore(a)).map(fmt),
    '',
    completed.length ? `COMPLETED:\n${completed.map(fmt).join('\n')}` : '',
  ].join('\n');
}

// ── Inline AI Tip on Task Card ─────────────────────
async function fetchAITip(task) {
  const system = `You are a concise productivity coach. Given a task, return ONE practical, specific tip in 12–18 words. No preamble. No quotation marks. Start with an action verb.`;
  const msg = `Task: "${task.title}"${task.desc ? '. Details: ' + task.desc : ''}. Priority: ${task.priority}.${task.due ? ' Due: ' + task.due + '.' : ''}`;
  try {
    const tip = await callClaude([{role:'user',content:msg}], system, 100);
    return tip.trim().replace(/^"+|"+$/g,'');
  } catch {
    return null;
  }
}

// Show/hide a spinner on a specific task card
function setCardLoading(taskId, loading) {
  const card = document.querySelector(`.task-card[data-id="${taskId}"]`);
  if (!card) return;
  const existing = card.querySelector('.task-ai-tip');
  if (loading) {
    if (!existing) {
      const el = document.createElement('div');
      el.className = 'task-ai-tip';
      el.innerHTML = `<span class="task-ai-tip-icon">⬡</span><span class="task-ai-tip-text" style="font-style:normal;color:var(--text3)"><span class="typing-dot"></span><span class="typing-dot"></span><span class="typing-dot"></span></span>`;
      card.querySelector('.task-body').appendChild(el);
    }
  }
}

async function addAITipToCard(taskId) {
  const task = tasks.find(t => t.id === taskId);
  if (!task || task.aiTip) return;

  setCardLoading(taskId, true);
  const tip = await fetchAITip(task);
  if (!tip) { setCardLoading(taskId, false); return; }

  task.aiTip = tip;
  save();

  // Update tip in DOM without full re-render
  const card = document.querySelector(`.task-card[data-id="${taskId}"]`);
  if (card) {
    const existing = card.querySelector('.task-ai-tip');
    if (existing) existing.remove();
    const el = document.createElement('div');
    el.className = 'task-ai-tip';
    el.innerHTML = `<span class="task-ai-tip-icon">⬡</span><span class="task-ai-tip-text">${esc(tip)}</span>`;
    card.querySelector('.task-body').appendChild(el);
  }
}

// ── Daily Briefing ─────────────────────────────────
async function loadDailyBriefing() {
  const pill = $('briefing-pill');
  const text  = $('briefing-text');
  if (tasks.filter(t=>!t.done).length === 0) return;

  pill.style.display = 'flex';
  text.textContent = 'Preparing briefing…';

  const system = `You are a focused productivity assistant. Given a task list, return ONE concise sentence (max 20 words) summarizing the most important thing the user should focus on today. Be direct and specific.`;
  try {
    const reply = await callClaude([{role:'user',content:taskContext()}], system, 80);
    text.textContent = reply.trim();
  } catch {
    pill.style.display = 'none';
  }
}

// ── Smart Recommendation Banner ────────────────────
async function loadRecommendationBanner() {
  const banner = $('ai-banner');
  const bannerText = $('ai-banner-text');
  const active = tasks.filter(t=>!t.done);
  if (active.length < 2) return;

  const system = `You are a task prioritization expert. Look at the user's tasks and give ONE specific, actionable recommendation in 1–2 sentences. Be direct. Start with what to do, not with "I recommend".`;
  try {
    const reply = await callClaude([{role:'user',content:taskContext()}], system, 120);
    bannerText.textContent = reply.trim();
    banner.style.display = 'flex';
  } catch {
    /* silently skip */
  }
}

// ── Render Task Card ───────────────────────────────
function renderTask(task) {
  const score = urgencyScore(task);
  const due   = dueInfo(task.due);
  const uCls  = urgencyClass(score);

  const div = document.createElement('div');
  div.className = [
    'task-card',
    `priority-${task.priority}`,
    task.done ? 'done-card' : '',
    due?.cls === 'overdue'  ? 'is-overdue' : '',
    due?.cls === 'today'    ? 'is-today'   : '',
  ].filter(Boolean).join(' ');
  div.dataset.id = task.id;

  const dueHtml = due
    ? `<span class="urgency-badge ${due.cls}">${due.badge}</span>`
    : '';

  const ringHtml = !task.done && score > 0
    ? `<div class="urgency-ring ${uCls}" title="Urgency score">${score}</div>`
    : '';

  const tipHtml = task.aiTip
    ? `<div class="task-ai-tip"><span class="task-ai-tip-icon">⬡</span><span class="task-ai-tip-text">${esc(task.aiTip)}</span></div>`
    : '';

  div.innerHTML = `
    <div class="task-check${task.done?' done':''}" data-check="${task.id}">${task.done?'✓':''}</div>
    <div class="task-body">
      <div class="task-title">${esc(task.title)}</div>
      ${task.desc ? `<div class="task-desc">${esc(task.desc)}</div>` : ''}
      ${tipHtml}
      <div class="task-meta">
        <span class="priority-badge ${task.priority}">${task.priority}</span>
        ${dueHtml}
      </div>
    </div>
    ${ringHtml}
    <div class="task-actions">
      ${!task.done && !task.aiTip ? `<button class="task-action-btn ai-btn" data-ai="${task.id}" title="Get AI tip">⬡</button>` : ''}
      <button class="task-action-btn" data-delete="${task.id}" title="Delete">✕</button>
    </div>
  `;

  div.querySelector(`[data-check="${task.id}"]`).addEventListener('click', () => toggleTask(task.id));
  div.querySelector(`[data-delete="${task.id}"]`).addEventListener('click', () => deleteTask(task.id));
  const aiBtn = div.querySelector(`[data-ai="${task.id}"]`);
  if (aiBtn) aiBtn.addEventListener('click', () => {
    aiBtn.style.display = 'none';
    addAITipToCard(task.id);
  });

  return div;
}

// ── Sort Tasks ─────────────────────────────────────
function sortedTasks(list) {
  return [...list].sort((a, b) => {
    if (currentSort === 'urgency')  return urgencyScore(b) - urgencyScore(a);
    if (currentSort === 'priority') {
      const w = { high: 3, medium: 2, low: 1 };
      return (w[b.priority]||0) - (w[a.priority]||0);
    }
    if (currentSort === 'due') {
      if (!a.due && !b.due) return 0;
      if (!a.due) return 1;
      if (!b.due) return -1;
      return new Date(a.due) - new Date(b.due);
    }
    // created (newest first)
    return (b.createdAt||0) - (a.createdAt||0);
  });
}

// ── Render Lists ───────────────────────────────────
function renderDashboard() {
  const list  = $('dashboard-task-list');
  const empty = $('dashboard-empty');

  let filtered = tasks.filter(t => !t.done);
  if (currentFilter === 'urgent') filtered = filtered.filter(isUrgent);
  else if (currentFilter !== 'all') filtered = filtered.filter(t => t.priority === currentFilter);

  list.innerHTML = '';
  if (filtered.length === 0) {
    empty.style.display = 'block';
    list.appendChild(empty);
  } else {
    empty.style.display = 'none';
    sortedTasks(filtered).forEach(t => list.appendChild(renderTask(t)));
  }
  updateStats();
  updateGreeting();
}

function renderAllTasks() {
  const list = $('all-task-list');
  const q = ($('search-input')?.value || '').toLowerCase();
  const filtered = tasks.filter(t =>
    t.title.toLowerCase().includes(q) || (t.desc || '').toLowerCase().includes(q)
  );

  list.innerHTML = '';
  if (filtered.length === 0) {
    list.innerHTML = `<div class="empty-state"><div class="empty-icon">🔍</div><p>No tasks match your search.</p></div>`;
  } else {
    sortedTasks(filtered).forEach(t => list.appendChild(renderTask(t)));
  }
}

function renderAll() {
  renderDashboard();
  if (currentView === 'tasks')     renderAllTasks();
  if (currentView === 'analytics') renderAnalytics();
}

// ── Stats ──────────────────────────────────────────
function updateStats() {
  const total   = tasks.length;
  const done    = tasks.filter(t => t.done).length;
  const urgent  = tasks.filter(t => isUrgent(t)).length;
  const pct     = total === 0 ? 0 : Math.round((done / total) * 100);

  $('stat-total-val').textContent   = total;
  $('stat-done-val').textContent    = done;
  $('stat-urgent-val').textContent  = urgent;
  $('stat-progress-val').textContent = pct + '%';

  $('done-bar').style.width    = pct + '%';
  $('progress-bar').style.width = pct + '%';
  $('urgent-bar').style.width   = total === 0 ? '0%' : Math.round((urgent/total)*100) + '%';
}

function updateGreeting() {
  const h = new Date().getHours();
  const greet = h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening';
  $('greeting').textContent = greet + ' ✦';

  const active  = tasks.filter(t => !t.done);
  const urgentN = active.filter(isUrgent).length;
  let summary = '';
  if (active.length === 0) summary = 'All caught up — nothing pending.';
  else if (urgentN > 0)    summary = `${active.length} active task${active.length>1?'s':''}, ${urgentN} urgent.`;
  else summary = `${active.length} active task${active.length>1?'s':''} — looking good.`;
  $('today-summary').textContent = summary;
}

// ── Analytics ──────────────────────────────────────
function renderAnalytics() {
  const total  = tasks.length;
  const done   = tasks.filter(t => t.done).length;
  const highN  = tasks.filter(t => t.priority==='high').length;
  const medN   = tasks.filter(t => t.priority==='medium').length;
  const lowN   = tasks.filter(t => t.priority==='low').length;
  const pct    = total === 0 ? 0 : Math.round((done/total)*100);

  // Donut
  const svg = $('donut-svg');
  $('donut-label').textContent = `${total} tasks`;
  svg.querySelectorAll('.dseg').forEach(e=>e.remove());
  const colors = {high:'#f87171', medium:'#fbbf24', low:'#34d399'};
  const entries = [['high',highN],['medium',medN],['low',lowN]];
  const r = 40, circ = 2*Math.PI*r;
  let offset = 0;
  entries.forEach(([p,c]) => {
    if (c===0) return;
    const frac = c/Math.max(total,1);
    const dash = frac*circ;
    const el = document.createElementNS('http://www.w3.org/2000/svg','circle');
    el.setAttribute('cx',60); el.setAttribute('cy',60); el.setAttribute('r',r);
    el.setAttribute('fill','none'); el.setAttribute('stroke',colors[p]);
    el.setAttribute('stroke-width',20);
    el.setAttribute('stroke-dasharray',`${dash} ${circ-dash}`);
    el.setAttribute('stroke-dashoffset',`${-offset*circ}`);
    el.setAttribute('class','dseg');
    svg.insertBefore(el, $('donut-label'));
    offset += frac;
  });
  $('donut-legend').innerHTML = entries.map(([p,c])=>`
    <div class="legend-item"><div class="legend-dot" style="background:${colors[p]}"></div><span>${p.charAt(0).toUpperCase()+p.slice(1)}: ${c}</span></div>`).join('');

  // Gauge
  const filled = Math.round((pct/100)*251);
  $('gauge-arc').setAttribute('stroke-dasharray',`${filled} 251`);
  $('gauge-pct').textContent = pct + '%';

  // Urgency map
  const map = $('urgency-map');
  const withDue = tasks.filter(t => t.due && !t.done).sort((a,b)=>urgencyScore(b)-urgencyScore(a)).slice(0,8);
  if (withDue.length === 0) {
    map.innerHTML = '<div class="no-data">Add tasks with due dates to see urgency mapping</div>';
    return;
  }
  const maxScore = Math.max(...withDue.map(t=>urgencyScore(t)), 1);
  const fillColor = s => s>=80?'#f87171':s>=55?'#fbbf24':s>=30?'#fb923c':'#34d399';
  map.innerHTML = withDue.map(t => {
    const s   = urgencyScore(t);
    const w   = Math.round((s/maxScore)*100);
    const due = dueInfo(t.due);
    return `
      <div class="urgency-row">
        <div class="urgency-row-name">${esc(t.title)}</div>
        <div class="urgency-row-track"><div class="urgency-row-fill" style="width:${w}%;background:${fillColor(s)}"></div></div>
        <div class="urgency-row-label">${due?.label||''}</div>
      </div>`;
  }).join('');
}

// ── Task CRUD ──────────────────────────────────────
function addTask(title, desc, priority, due) {
  const task = { id:uid(), title, desc, priority, due, done:false, createdAt:Date.now(), aiTip:null };
  tasks.unshift(task);
  save();
  renderAll();
  return task;
}

function toggleTask(id) {
  const t = tasks.find(t=>t.id===id);
  if (t) { t.done = !t.done; save(); renderAll(); }
}

function deleteTask(id) {
  tasks = tasks.filter(t=>t.id!==id);
  save(); renderAll();
  toast('Task removed');
}

// ── View Switching ─────────────────────────────────
function switchView(view) {
  currentView = view;
  document.querySelectorAll('.view').forEach(v=>v.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n=>n.classList.remove('active'));
  $('view-'+view).classList.add('active');
  document.querySelector(`[data-view="${view}"]`)?.classList.add('active');
  if (view==='analytics') renderAnalytics();
  if (view==='tasks')     renderAllTasks();
  if (view==='ai')        $('ai-nav-badge').style.display='none';
}

// ── Modal ──────────────────────────────────────────
function openModal() {
  $('modal-overlay').classList.add('open');
  setTimeout(()=>$('task-title-input').focus(), 100);
}
function closeModal() {
  $('modal-overlay').classList.remove('open');
  $('task-title-input').value = '';
  $('task-desc-input').value  = '';
  $('task-priority-input').value = 'medium';
  $('task-due-input').value   = '';
}

// ── Save Task ──────────────────────────────────────
async function saveTask() {
  const title    = $('task-title-input').value.trim();
  if (!title) { $('task-title-input').focus(); toast('Please enter a title', '', 2000); return; }
  const desc     = $('task-desc-input').value.trim();
  const priority = $('task-priority-input').value;
  const due      = $('task-due-input').value;
  const wantAI   = $('ai-suggest-check').checked;

  closeModal();
  const task = addTask(title, desc, priority, due);

  if (wantAI) {
    toast('⬡ Claude is crafting a tip for your task…', 'ai', 4000);
    const tip = await fetchAITip(task);
    if (tip) {
      task.aiTip = tip;
      save();
      // Inject into card if it's visible
      const card = document.querySelector(`.task-card[data-id="${task.id}"]`);
      if (card) {
        const existing = card.querySelector('.task-ai-tip');
        if (existing) existing.remove();
        const aiBtn = card.querySelector(`[data-ai="${task.id}"]`);
        if (aiBtn) aiBtn.remove();
        const el = document.createElement('div');
        el.className = 'task-ai-tip';
        el.innerHTML = `<span class="task-ai-tip-icon">⬡</span><span class="task-ai-tip-text">${esc(tip)}</span>`;
        card.querySelector('.task-body').appendChild(el);
      }
      toast(`⬡ ${tip}`, 'ai', 6000);
    }
  }
}

// ── Chat ───────────────────────────────────────────
function appendBubble(text, role) {
  const win = $('chat-window');
  const div = document.createElement('div');
  div.className = `chat-bubble ${role}`;
  const icon = role === 'assistant' ? '⬡' : '✦';
  const html = text
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/\*\*(.*?)\*\*/g,'<strong>$1</strong>')
    .replace(/\n/g,'<br>');
  div.innerHTML = `<div class="bubble-avatar">${icon}</div><div class="bubble-text">${html}</div>`;
  win.appendChild(div);
  win.scrollTop = win.scrollHeight;
}

function showTyping() {
  const win = $('chat-window');
  const div = document.createElement('div');
  div.className = 'chat-bubble assistant typing-bubble';
  div.id = 'typing-ind';
  div.innerHTML = `<div class="bubble-avatar">⬡</div><div class="bubble-text"><span class="typing-dot"></span><span class="typing-dot"></span><span class="typing-dot"></span></div>`;
  win.appendChild(div);
  win.scrollTop = win.scrollHeight;
}
function hideTyping() { $('typing-ind')?.remove(); }

async function sendChatMessage() {
  const input = $('chat-input');
  const msg   = input.value.trim();
  if (!msg) return;
  input.value = '';

  appendBubble(msg, 'user');
  chatHistory.push({ role: 'user', content: msg });
  showTyping();

  const system = `You are TaskAI, an expert productivity assistant powered by Claude. You have full context of the user's tasks below. Help them prioritize, plan, break down tasks, and stay on track. Be concise, practical, and encouraging.

${taskContext()}`;

  try {
    // Keep last 10 turns to avoid context overflow
    const msgs = chatHistory.slice(-10);
    const reply = await callClaude(msgs, system, 600);
    hideTyping();
    appendBubble(reply, 'assistant');
    chatHistory.push({ role: 'assistant', content: reply });
  } catch {
    hideTyping();
    appendBubble('⚠️ Could not connect to Claude. Check that your API key is set in app.js.', 'assistant');
  }
}

// ── Event Listeners ────────────────────────────────
document.querySelectorAll('[data-view]').forEach(el =>
  el.addEventListener('click', e => { e.preventDefault(); switchView(el.dataset.view); })
);

['open-add-modal','open-add-modal-2','open-add-modal-3'].forEach(id => {
  $(id)?.addEventListener('click', openModal);
});
$('close-modal').addEventListener('click', closeModal);
$('cancel-modal').addEventListener('click', closeModal);
$('modal-overlay').addEventListener('click', e => { if (e.target===$('modal-overlay')) closeModal(); });
$('save-task-btn').addEventListener('click', saveTask);
$('task-title-input').addEventListener('keydown', e => { if (e.key==='Enter') saveTask(); });

document.querySelectorAll('.filter-pill').forEach(pill =>
  pill.addEventListener('click', () => {
    document.querySelectorAll('.filter-pill').forEach(p=>p.classList.remove('active'));
    pill.classList.add('active');
    currentFilter = pill.dataset.filter;
    renderDashboard();
  })
);

document.querySelectorAll('.sort-pill').forEach(pill =>
  pill.addEventListener('click', () => {
    document.querySelectorAll('.sort-pill').forEach(p=>p.classList.remove('active'));
    pill.classList.add('active');
    currentSort = pill.dataset.sort;
    renderAllTasks();
  })
);

$('search-input')?.addEventListener('input', renderAllTasks);

$('send-chat-btn').addEventListener('click', sendChatMessage);
$('chat-input').addEventListener('keydown', e => { if (e.key==='Enter') sendChatMessage(); });

document.querySelectorAll('.suggestion-chip').forEach(chip =>
  chip.addEventListener('click', () => {
    $('chat-input').value = chip.dataset.prompt;
    sendChatMessage();
  })
);

$('ai-banner-close')?.addEventListener('click', () => {
  $('ai-banner').style.display = 'none';
});

// ── Init ───────────────────────────────────────────
if (tasks.length === 0) {
  const tPlus = n => new Date(Date.now() + n*86400000).toISOString().slice(0,10);
  tasks = [
    { id:uid(), title:'Design landing page mockup', desc:'Create wireframes and a high-fidelity prototype for the homepage', priority:'high', due:tPlus(1), done:false, createdAt:Date.now()-7200000, aiTip:'Start with mobile layout first — 60% of traffic is mobile.' },
    { id:uid(), title:'Set up Claude API integration', desc:'Add API key to environment variables and test all endpoints', priority:'high', due:tPlus(0), done:false, createdAt:Date.now()-5400000, aiTip:null },
    { id:uid(), title:'Write README documentation', desc:'Include setup instructions, feature list, and deployment guide', priority:'medium', due:tPlus(4), done:false, createdAt:Date.now()-3600000, aiTip:'Use screenshots and GIFs — visual docs cut support questions by 50%.' },
    { id:uid(), title:'Deploy to Vercel', desc:'Set up CI/CD pipeline from GitHub and configure environment variables', priority:'medium', due:tPlus(6), done:false, createdAt:Date.now()-1800000, aiTip:null },
    { id:uid(), title:'Research competitor apps', desc:'Analyse top 5 task managers for feature gaps and UX inspiration', priority:'low', due:tPlus(10), done:false, createdAt:Date.now()-900000, aiTip:null },
    { id:uid(), title:'Set up project repo on GitHub', desc:'Init repo, add .gitignore, push initial commit', priority:'high', due:'', done:true, createdAt:Date.now()-10800000, aiTip:null },
  ];
  save();
}

renderAll();

// Load AI features after a short delay so the UI paints first
setTimeout(() => {
  loadDailyBriefing();
  loadRecommendationBanner();
}, 600);
